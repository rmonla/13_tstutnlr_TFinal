<?php  
/*<®> fxsBD <®>*/
	include_once 'fxsBD.php';

?>
