<?php  
/*<®> Includes <®>*/
	include_once 'fxs.php';
	include_once 'dbf_class.php';
/*<®> fx burcarId <®>*/
	/**
	 * Función que retorna el id de un registro en una tabla según un valor.
	 */
	function burcarId($tbl, $val){
		$arr_pram = array('agrupaciones' => array(
											'agru',
											'idagru'),
								'areas' => array(
											'area',
											'idarea'),
								'zonas' => array(
											'zona',
											'idzona'),
								'agentes' => array(
											'docu',
											'idagente'),
								'planes' => array(
											'plan',
											'idplan')
						);
		$where = $arr_pram[$tbl][0]."='$val'";
		$id    = buscarReg($tbl, $where, $arr_pram[$tbl][1]);
		return $id;
	}
/*<®> Verificación Inicial <®>*/
	if(!isset($_GET['dbf'], $_GET['ult_fila'])){
		echo "No se recibió el archivo DBF.";
	}else{
		/*<®> Variables <®>*/
			$ult_fila = $_GET['ult_fila'];
			$dbf_arch = $_GET['dbf'];
			$dbf_arch  = '../uploads/dbfs/'.$dbf_arch;
		/*<®> Cargo el DBF <®>*/
			$dbf       = new dbf_class($dbf_arch);
			$dbf_filas = $dbf->dbf_num_rec;
		/*<®> Array de Importaciones y Wheres<®>*/
			$arr_imps = array(
								'agentes' => array(
													'docu' => 0, 
													'cuil' => 1, 
													'nom'  => 3, 
													'sexo' => 4),
								'zonas' => array(
													'zona' => 5),
								'areas' => array(
													'area' => 33),
								'planes' => array(
													'plan' => 12),
								'agrupaciones' => array(
													'agru' => 19),
								'cargos' => array(
													'idagru' => 19,
													'cargo' => 19),
								'escuelas' => array(
													'idarea' => 33,
													'idzona' => 5,
													'escu'   => 7),
								'liquidaciones' => array(
													'idagente' => 0,
													'idplan'   => 12,
													'idcargo'  => 19,
													'idescu'   => 7,
													'trab'     => 2,
													'anti'     => 17,
													'hora'     => 18,
													'dias'     => 22,
													'periodo'  => '?')
								);
								/*@idarea + @idzona + @escu*/
			$arr_wres = array(
								'agentes'      => array('docu'),
								'zonas'        => array('zona'),
								'areas'        => array('area'),
								'planes'       => array('plan'),
								'agrupaciones' => array('agru')
							);
		/*<®> Importación <®>*/
			$t_ini = time();
			$t=0;
			for ($i=$ult_fila; $i<$dbf_filas and $t<=20; $i++){
				/*<®> Cargo la fila del dbf<®>*/
					$dbf_reg = $dbf->getRow($i);
				foreach ($arr_imps as $tbl => $cols) {
					/*<®> Armo el where para buscarlo en la BD<®>*/
						switch ($tbl) {
							case 'cargos':
									$idagru = burcarId('agrupaciones', $dbf_reg[19]);
									$cargo  = $dbf_reg[20].$dbf_reg[21];
									$where  = "idagru='$idagru' AND cargo='$cargo'";
								break;
							case 'escuelas':
									$idarea = burcarId('areas', $dbf_reg[33]);
									$idzona = burcarId('zonas', $dbf_reg[5]);
									$escu   = $dbf_reg[7];
									$where  = "idarea='$idarea' AND idzona='$idzona' AND escu='$escu'";
								break;
							case 'liquidaciones':
									$idagente = burcarId('agentes', $dbf_reg[0]);
									/* idescu */
										$idarea = burcarId('areas', $dbf_reg[33]);
										$idzona = burcarId('zonas', $dbf_reg[5]);
										$escu   = $dbf_reg[7];
										$where  = "idarea='$idarea' AND idzona='$idzona' AND escu='$escu'";
									$idescu = buscarReg('escuelas', $where, 'idescu');
									$trab   = $dbf_reg[2];
									/* periodo */
										$periodo = explode('.', $_GET['dbf']);
									$periodo = $periodo[0]; //Periodo es el nombre del archivo dbf.
									$where   = "idagente='$idagente' AND idescu='$idescu' AND trab='$trab' AND periodo='$periodo'";
								break;
							
							default:
								$where = '';
								foreach ($arr_wres[$tbl] as $col_tbl) {
									$col_dbf = $cols[$col_tbl];
									$where   = "$col_tbl='$dbf_reg[$col_dbf]'";
								}
								break;
						}
					/*<®> Lo importo si no está cargado <®>*/
						if (!buscarReg($tbl, $where)) {
							/*<®> Armo las string de encabezados y datos para la sql<®>*/
								$enc = '';
								$dat = '';
								switch ($tbl) {
									case 'cargos':
										$idagru = burcarId('agrupaciones', $dbf_reg[19]);
										$cargo  = $dbf_reg[20].$dbf_reg[21];
										$enc    = "idagru,cargo";
										$dat    = "'$idagru','$cargo'";
										break;
									case 'escuelas':
										/* Valores de datos */
											$idarea = burcarId('areas', $dbf_reg[33]);
											$idzona = burcarId('zonas', $dbf_reg[5]);
											$escu   = $dbf_reg[7];
										/* Encabezados y Datos */
											$enc = "idarea,idzona,escu";
											$dat = "'$idarea','$idzona','$escu'";
										break;
									case 'liquidaciones':
										/* Valores de datos */
											$idagente = burcarId('agentes', $dbf_reg[0]);
											$idplan   = burcarId('planes', $dbf_reg[12]);
											/* idcargo */
												$idagru = burcarId('agrupaciones', $dbf_reg[19]);
												$cargo  = $dbf_reg[20].$dbf_reg[21];
												$where  = "idagru='$idagru' AND cargo='$cargo'";
											$idcargo = buscarReg('cargos', $where, 'idcargo');
											/* idescu */
												$idarea = burcarId('areas', $dbf_reg[33]);
												$idzona = burcarId('zonas', $dbf_reg[5]);
												$escu   = $dbf_reg[7];
												$where  = "idarea='$idarea' AND idzona='$idzona' AND escu='$escu'";
											$idescu = buscarReg('escuelas', $where, 'idescu');
											$trab   = $dbf_reg[2];
											$anti   = $dbf_reg[17];
											$hora   = $dbf_reg[18];
											$dias   = $dbf_reg[22];
											/* periodo */
												$periodo = explode('.', $_GET['dbf']);
											$periodo = $periodo[0]; //Periodo es el nombre del archivo dbf.
										/* Encabezados y Datos */
											$enc = "idagente,idplan,idcargo,idescu,trab,anti,hora,dias,periodo";
											$dat = "'$idagente','$idplan','$idcargo','$idescu','$trab','$anti','$hora','$dias','$periodo'";
										break;
									
									default:
										foreach ($cols as $col_tbl => $col_dbf) {
											$enc.= ",$col_tbl";
											$dat.= ",'$dbf_reg[$col_dbf]'";
										}
										$enc = substr($enc,1);
										$dat = substr($dat,1);
										break;
								}
							/*<®> Inserto el registro <®>*/
								$sql = "INSERT INTO $tbl ( $enc ) VALUES ( $dat )";
								ejecutar($sql);
						}
				}
				$t = time() - $t_ini;
			}
		/*<®> Verifico si llegó al final y lo registro en la BD<®>*/
			$ult_fila = $i;
			$estado = ($ult_fila == $dbf_filas) ? 'Terminado' : 'Importando' ;
	/*<®> Muestro una tabla con los resultados <®>*/
?>
	<table>
		<tr>
			<th align="center">Estado</th>
			<th align="center">Fila</th>
			<?php 
				foreach ($arr_imps as $tbl => $cols) {
			 ?>
				<th align="center"><?php echo ucfirst($tbl); ?></th>
			<?php 
				} 
			?>
		</tr>
		<tr>
			<td align="center">
				<div id="imp_estado">
					<?php echo $estado; ?>
				</div>
			</td>
			<td align="center">
				<div id="ult_fila">
					<?php echo $ult_fila; ?>
				</div>
			</td>
			<?php 
				foreach ($arr_imps as $tbl => $cols) { 
			?>
				<td>
					<div align="center">
						<?php echo contarRegs($tbl); ?>
					</div>
				</td>
			<?php 
				} 
			?>
		</tr>
	</table>
<?php 
	} 
?>
