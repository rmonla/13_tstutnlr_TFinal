<?php  
/*<®> Includes <®>*/
	include_once 'fxs.php';
	include_once 'dbf_class.php';
/*<®> fx burcarId <®>*/
	/**
	 * Función que retorna el id de un registro en una tabla según un valor.
	 */
	function burcarId($tbl, $val){
		$arr_pram = array('agrupaciones' => array(
											'agru',
											'idagru'),
								'areas' => array(
											'area',
											'idarea'),
								'zonas' => array(
											'zona',
											'idzona'),
								'agentes' => array(
											'docu',
											'idagente'),
								'planes' => array(
											'plan',
											'idplan')
						);
		$where = $arr_pram[$tbl][0]."='$val'";
		$id    = buscarReg($tbl, $where, $arr_pram[$tbl][1]);
		return $id;
	}
/*<®> Verificación Inicial <®>*/
	if(!isset($_GET['dbf'], $_GET['ult_fila'])){
		echo "No se recibió el archivo DBF.";
	}else{
		/*<®> Variables <®>*/
			$ult_fila = $_GET['ult_fila'];
			$dbf_arch = $_GET['dbf'];
			$dbf_arch  = '../uploads/dbfs/'.$dbf_arch;
		/* periodo */
			$periodo = explode('.', $_GET['dbf']);
			$periodo = $periodo[0];
		/*<®> Cargo el DBF <®>*/
			$dbf       = new dbf_class($dbf_arch);
			$dbf_filas = $dbf->dbf_num_rec;
		/*<®> Cargo array de tablas (Columnas, Condiciones de Búsquedas, Columnas Tupla) <®>*/
			$tblscols = array(
								'zonas'         => array('cols' => array(),
																'where' => '',
																'tupla' => array('zona')),
								'areas'         => array('cols' => array(),
																'where' => '',
																'tupla' => array('area')),
								'planes'        => array('cols' => array(),
																'where' => '',
																'tupla' => array('plan')),
								'agrups'        => array('cols' => array(),
																'where' => '',
																'tupla' => array('agru')),
								'periodos'      => array('cols' => array(),
																'where' => '',
																'tupla' => array('periodo')),
								'agentes'       => array('cols' => array(),
																'where' => '',
																'tupla' => array('docu')),
								'escus'         => array('cols' => array(),
																'where' => '',
																'tupla' => array('idzona','escu')),
								'escu_areas'    => array('cols' => array(),
																'where' => '',
																'tupla' => array('idescu','idarea')),
								'a_p'           => array('cols' => array(),
																'where' => '',
																'tupla' => array('idagente','idplan')),
								'cargos'        => array('cols' => array(),
																'where' => '',
																'tupla' => array('idagru','cargo')),
								'a_p_c_ea'      => array('cols' => array(),
																'where' => '',
																'tupla' => array('ida_p','idcargo','idescu_area')),
								'liqs'          => array('cols' => array(),
																'where' => '',
																'tupla' => array('ida_p_c_ea','idperiodo','trab'))
							);
		/*<®> Cargo desde la BD las columnas de las tablas <®>*/
			foreach ($tblscols as $tbl => $val) {
				$cols = cargarColumnasDeTabla($tbl);
				while($col = mysql_fetch_array($cols)){
					array_push($tblscols[$tbl]['cols'], $col['Field']);
				}
			}
		/*<®> Cargo el array de valores de columnas dentro de la DBF <®>*/
			$dbfcolval = array(
								'docu' => 0,
								'cuil' => 1,
								'trab' => 2,
								'nom'  => 3,
								'sexo' => 4,
								'zona' => 5,
								'escu' => 7,
								'plan' => 12,
								'anti' => 17,
								'hora' => 18,
								'agru' => 19,
								'lcat' => 20,
								'ncat' => 21,
								'dias' => 22,
								'area' => 33
							);
		/*<®> Cargo el array de tablas con sus nombres que se mostraran al final <®>*/
			$arr_mostrar = array(
									'zonas'    => 'Zonas',
									'areas'    => 'Areas',
									'planes'   => 'Planes',
									'agrups'   => 'Agrupaciones',
									'periodos' => 'Periodos',
									'agentes'  => 'Agentes',
									'escus'    => 'Escuelas',
									'cargos'   => 'Cargos',
									'liqs'     => 'Liquidaciones'
								);
		/*<®> Tomo el tiempo <®>*/
			$t_ini = time();
			$t=0;
		/*<®> Se cargarán registros mientras 
				no llegue al final de la DBF 
				y el tiempo no supere los 25s <®>*/
			for ($i=$ult_fila; $i<$dbf_filas and $t<=20; $i++){
				/*<®> Cargo la fila del dbf<®>*/
					$dbf_reg = $dbf->getRow($i);
				foreach ($tblscols as $tbl => $vals) {
					/*<®> Armo el where para buscarlo en la BD<®>*/
						$tblscols[$tbl]['where'] = '';
						switch ($tbl) {
							case 'periodos':
									$tblscols[$tbl]['where'].= " AND periodo='$periodo'";
								break;
							case 'escus':
									$stbl = 'zonas';
									$idzona = buscarReg($stbl, $tblscols[$stbl]['where'], 'id');
									$tblscols[$tbl]['where'].= " AND idzona='$idzona'";
								break;
							case 'escu_areas':
								//idescu
									$stbl = 'escus';
									$idescu = buscarReg($stbl, $tblscols[$stbl]['where'], 'id');
									$tblscols[$tbl]['where'].= " AND idescu='$idescu'";
								//idarea
									$stbl = 'areas';
									$idarea = buscarReg($stbl, $tblscols[$stbl]['where'], 'id');
									$tblscols[$tbl]['where'].= " AND idarea='$idarea'";
								break;
							case 'a_p':
								/* idagente */
									$stbl = 'agentes';
									$idagente = buscarReg($stbl, $tblscols[$stbl]['where'], 'id');
									$tblscols[$tbl]['where'].= " AND idagente='$idagente'";
								/* idplan */
									$stbl = 'planes';
									$idplan = buscarReg($stbl, $tblscols[$stbl]['where'], 'id');
									$tblscols[$tbl]['where'].= " AND idplan='$idplan'";
								break;
							case 'cargos':
								/* idagru */
									$stbl = 'agrups';
									$idagru = buscarReg($stbl, $tblscols[$stbl]['where'], 'id');
									$tblscols[$tbl]['where'].= " AND idagru='$idagru'";
								/* cargo */
									$cargo = $dbf_reg[$dbfcolval['lcat']].$dbf_reg[$dbfcolval['ncat']];
									$tblscols[$tbl]['where'].= " AND cargo='$cargo'";
								break;
							case 'a_p_c_ea':
								/* ida_p */
									$stbl = 'a_p';
									$ida_p = buscarReg($stbl, $tblscols[$stbl]['where'], 'id');
									$tblscols[$tbl]['where'].= " AND ida_p='$ida_p'";
								/* idcargo */
									$stbl = 'cargos';
									$idcargo = buscarReg($stbl, $tblscols[$stbl]['where'], 'id');
									$tblscols[$tbl]['where'].= " AND idcargo='$idcargo'";
								/* idescu_area */
									$stbl = 'escu_areas';
									$idescu_area = buscarReg($stbl, $tblscols[$stbl]['where'], 'id');
									$tblscols[$tbl]['where'].= " AND idescu_area='$idescu_area'";
								break;
							case 'liqs':
								/* ida_p_c_ea */
									$stbl = 'a_p_c_ea';
									//var_dump($tblscols[$stbl]['where']);
									//exit;
									$ida_p_c_ea = buscarReg($stbl, $tblscols[$stbl]['where'], 'id');
									$tblscols[$tbl]['where'].= " AND ida_p_c_ea='$ida_p_c_ea'";
								/* idperiodo */
									$stbl = 'periodos';
									$idperiodo = buscarReg($stbl, $tblscols[$stbl]['where'], 'id');
									$tblscols[$tbl]['where'].= " AND idperiodo='$idperiodo'";
							
							default:
								break;
						}
						foreach ($tblscols[$tbl]['tupla'] as $col) {
							if (isset($dbfcolval[$col])){
								$val = $dbf_reg[$dbfcolval[$col]];
								$tblscols[$tbl]['where'].= " AND $col='$val'";
							}
						}
						$tblscols[$tbl]['where'] = substr($tblscols[$tbl]['where'],5);
					/*<®> Lo importo si no está cargado <®>*/
						if (!buscarReg($tbl, $tblscols[$tbl]['where'])) {
							/*<®> Armo las string de encabezados y datos para la sql<®>*/
								$enc = '';
								$dat = '';
								switch ($tbl) {
									case 'periodos':
											$enc.= ",periodo";
											$dat.= ",'$periodo'";
										break;
									case 'escus':
											$enc.= ",idzona";
											$dat.= ",'$idzona'";
										break;
									case 'escu_areas':
											$enc.= ",idescu,idarea";
											$dat.= ",'$idescu','$idarea'";
										break;
									case 'a_p':
											$enc.= ",idagente,idplan";
											$dat.= ",'$idagente','$idplan'";
										break;
									case 'cargos':
											$enc.= ",idagru,cargo";
											$dat.= ",'$idagru','$cargo'";
										break;
									case 'a_p_c_ea':
											$enc.= ",ida_p,idcargo,idescu_area";
											$dat.= ",'$ida_p','$idcargo','$idescu_area'";
										break;
									case 'liqs':
											$enc.= ",ida_p_c_ea,idperiodo";
											$dat.= ",'$ida_p_c_ea','$idperiodo'";
										break;
									
									default:
										break;
								}
								foreach ($tblscols[$tbl]['cols'] as $col) {
									if (isset($dbfcolval[$col])){
										$enc.= ",$col";
										$dat.= ",'".$dbf_reg[$dbfcolval[$col]]."'";
									}
								}
								$enc = substr($enc,1);
								$dat = substr($dat,1);
							/*<®> Inserto el registro <®>*/
								$sql = "INSERT INTO $tbl ( $enc ) VALUES ( $dat )";
								ejecutar($sql);
						}
				}
				$t = time() - $t_ini;
			}
		/*<®> Verifico si llegó al final y lo registro en la BD<®>*/
			$ult_fila = $i;
			$estado = ($ult_fila == $dbf_filas) ? 'Terminado' : 'Importando' ;
	/*<®> Muestro una tabla con los resultados <®>*/
?>
	<table>
		<tr>
			<th align="center">Estado</th>
			<th align="center">Fila</th>
			<?php 
				foreach ($arr_mostrar as $tbl => $nombre) {
			 ?>
				<th align="center"><?php echo ucfirst($nombre); ?></th>
			<?php 
				} 
			?>
		</tr>
		<tr>
			<td align="center">
				<div id="imp_estado">
					<?php echo $estado; ?>
				</div>
			</td>
			<td align="center">
				<div id="ult_fila">
					<?php echo $ult_fila; ?>
				</div>
			</td>
			<?php 
				foreach ($arr_mostrar as $tbl => $nombre) { 
			?>
				<td>
					<div align="center">
						<?php echo contarRegs($tbl); ?>
					</div>
				</td>
			<?php 
				} 
			?>
		</tr>
	</table>
<?php 
	} 
?>
