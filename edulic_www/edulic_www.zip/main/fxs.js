function buscarReg (tbl, col, id) {
	if (window.XMLHttpRequest) { // code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else { // code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
			//document.getElementById("txtHint").innerHTML = xmlhttp.responseText;
			return xmlhttp.responseText;
		}
	}
	xmlhttp.open("POST", "main/buscarreg.php?tbl=" + tbl + "&col=" + col + "&id=" + id, true);
	xmlhttp.send();
}
function dbf_contarFilas (dbf_arch) {
	if (window.XMLHttpRequest) { // code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else { // code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
			importarDBF (dbf_arch, xmlhttp.responseText);
		}
	}
	xmlhttp.open("GET", "main/dbf_contarfilas.php?dbf_arch=" + dbf_arch, true);
	xmlhttp.send();
}


function dbf_importarReg (tbl, dbf_fila) {
	var dbf_arch = document.getElementById("dbf_arch").innerHTML;
	if (window.XMLHttpRequest) { // code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp = new XMLHttpRequest();
	} else { // code for IE6, IE5
		xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange = function() {
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
			document.getElementById("dbf_estado").innerHTML = xmlhttp.responseText;
			importarDesdeDBF();
		}
	}
	xmlhttp.open("GET", "main/dbf_importarreg.php?tbl=" + tbl + "&dbf_arch=" + dbf_arch + "&dbf_fila=" + dbf_fila, true);
	xmlhttp.send();
}
function importarDesdeDBF(){
	var estado = document.getElementById('dbf_estado').innerHTML
	//alert(document.getElementById('dbf_estado').innerHTML);
	switch(estado){
		case 'Importado':
	  		document.getElementById("dbf_importado").innerHTML = parseInt(document.getElementById("dbf_importado").innerHTML) + 1;
	  		var fila = parseInt(document.getElementById("dbf_fila").innerHTML) + 1;
		  break;
		case 'Encontrado':
	  		document.getElementById("dbf_encontrado").innerHTML = parseInt(document.getElementById("dbf_encontrado").innerHTML) + 1;
	  		var fila = parseInt(document.getElementById("dbf_fila").innerHTML) + 1;
	  		break;
		case 'Error':
	  		document.getElementById("dbf_error").innerHTML = parseInt(document.getElementById("dbf_error").innerHTML) + 1;
	  		var fila = parseInt(document.getElementById("dbf_fila").innerHTML) + 1;
	  		break;
		default: //'Iniciar'
	  		var fila = 0;
	}

	var dbf_filas = parseInt(document.getElementById("dbf_filas").innerHTML);
	
	if ( fila < dbf_filas){
  		document.getElementById("dbf_fila").innerHTML = parseInt(document.getElementById("dbf_fila").innerHTML) + 1;
		dbf_importarReg ('agentes', fila);
	}
}